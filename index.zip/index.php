<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proma Africa - Property Valuation & Real Estate Services</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <a href="index.php"><img src="1.jpg" alt="Proma Africa Logo"></a>
            </div>
            <div class="hamburger-menu">
                <div class="menu-icon" id="menuIcon">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="menu-links" id="menuLinks">
                    <a href="index.php">Home</a>
                    <a href="#about">About Us</a>
                    <a href="#services">Services</a>
                    <a href="#news">News and Blogs</a>
                    <a href="#contact">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section with Video -->
    <section class="hero">
        <video autoplay muted loop id="hero-video">
            <source src="vid.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <div class="hero-content">
            <h1>Revolutionizing Real Estate Through Innovative Solutions</h1>
            <p>Your trusted partner in property valuation, land administration, and real estate services</p>
            <a href="#contact" class="cta-button">Get Started</a>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2>Company Profile: Proma Africa</h2>
            <div class="about-content">
                <div class="about-text">
                    <h3>Company Overview</h3>
                    <p>Proma Africa is a multifaceted company specializing in property valuation, land administration, real estate services, resettlement consultancy, socio-economic baseline survey and comprehensive consultancy services. With a commitment to excellence and a client-centric approach, we aim to deliver tailored solutions that meet the diverse needs of our clients across various sectors.</p>
                    
                    <p>Proma Africa Company Limited is a one-stop boutique valuation company to Individuals, Corporations & Governments operating, covering all movable and immovable assets.</p>
                    
                    <p>Proma Africa Company Limited was incorporated in April 2024 by a team of experienced experts in property valuation, Resettlement, Environmental Social Governance (ESG), Social Economic Surveys Socioeconomic Sciences (SIS), earth observation (EO) as well as, Real Estate and Market Analysis with more than 5 years of experience. The specific solutions offered include but not limited to those harnessing 'Value' as an important variable in sustainable investments. The founders and experts in the company believe that a 'value' is a decision support tool in any investment appraisal. For service providers, the value can provide a synoptic view of the asset being appraised.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Mission & Vision Section -->
    <section class="mission-vision">
        <div class="container">
            <div class="mission">
                <h3>Our Mission</h3>
                <p>To revolutionize the real estate industry through innovative solutions and expert consultancy, empowering clients to make informed decisions and achieve optimal outcomes.</p>
            </div>
            <div class="vision">
                <h3>Our Vision</h3>
                <p>To become the top tier in transforming the valuation, land administration, real estate industry and resettlement through innovative technology and expert consultancy, creating a more efficient, transparent, and sustainable future for all stakeholders.</p>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <h2>Our Services</h2>
            <div class="services-grid">
                <div class="service-card">
                    <i class="fas fa-building"></i>
                    <h3>Property Valuation</h3>
                    <p>Comprehensive valuation services for all types of properties.</p>
                </div>
                <div class="service-card">
                    <i class="fas fa-map-marked-alt"></i>
                    <h3>Land Administration</h3>
                    <p>Expert services in land management and administration.</p>
                </div>
                <div class="service-card">
                    <i class="fas fa-map-marked-alt"></i>
                    <h3>Plots,Farms & Houses</h3>
                    <p>Expert services in land management and administration.</p>
                </div>
                <div class="service-card">
                    <i class="fas fa-home"></i>
                    <h3>Real Estate Services</h3>
                    <p>Full-spectrum real estate consultancy for diverse needs.</p>
                </div>
                <div class="service-card">
                    <i class="fas fa-people-arrows"></i>
                    <h3>Resettlement Consultancy</h3>
                    <p>Ethical and efficient resettlement planning and implementation.</p>
                </div>
                <div class="service-card">
                    <i class="fas fa-chart-line"></i>
                    <h3>Socio-Economic Surveys</h3>
                    <p>Comprehensive baseline surveys and data analysis.</p>
                </div>
                <div class="service-card">
                    <i class="fas fa-handshake"></i>
                    <h3>Consultancy Services</h3>
                    <p>Tailored consultancy solutions for diverse client needs.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2>Contact Us</h2>
            <div class="contact-wrapper">
                <form class="contact-form">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" rows="5" required></textarea>
                    </div>
                    <button type="submit" class="submit-btn">Send Message</button>
                </form>
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <p>info@promaafrica.com</p>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <p>+123 456 7890</p>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <p>Nairobi, Kenya</p>
                    </div>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">
                    <img src="1.jpg" alt="Proma Africa Logo">
                    <p>Your trusted partner in property valuation and real estate services.</p>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#about">About Us</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-newsletter">
                    <h4>Newsletter</h4>
                    <p>Subscribe to our newsletter for the latest updates</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your Email Address">
                        <button type="submit">Subscribe</button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Proma Africa. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // JavaScript for hamburger menu toggle
        document.getElementById('menuIcon').addEventListener('click', function() {
            document.getElementById('menuLinks').classList.toggle('show');
        });

        // Close menu when clicking elsewhere
        document.addEventListener('click', function(event) {
            const menuLinks = document.getElementById('menuLinks');
            const menuIcon = document.getElementById('menuIcon');
            
            if (!menuIcon.contains(event.target) && !menuLinks.contains(event.target)) {
                menuLinks.classList.remove('show');
            }
        });
    </script>
</body>
</html>